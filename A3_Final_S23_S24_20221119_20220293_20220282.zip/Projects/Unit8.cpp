//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Unit8.h"
#include "Unit5.h"
#include "Unit2.h"
#include "Unit4.h"
#include "Unit7.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm8 *Form8;
//---------------------------------------------------------------------------
__fastcall TForm8::TForm8(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm8::Button1Click(TObject *Sender)
{
TForm5 *Form5 = new TForm5(this);
Form5->ShowModal();

}
//---------------------------------------------------------------------------
void __fastcall TForm8::Button2Click(TObject *Sender)
{
		TForm2 *Form2 = new TForm2(this);
Form2->ShowModal();

}
//---------------------------------------------------------------------------
void __fastcall TForm8::Button3Click(TObject *Sender)
{
TForm4 *Form4 = new TForm4(this);
Form4->ShowModal();

}
//---------------------------------------------------------------------------
void __fastcall TForm8::Button4Click(TObject *Sender)
{
TForm7 *Form7 = new TForm7(this);
Form7->ShowModal();

}
//---------------------------------------------------------------------------
