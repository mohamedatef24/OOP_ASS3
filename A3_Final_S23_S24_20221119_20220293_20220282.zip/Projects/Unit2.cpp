//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm2 *Form2;

Char cps='x';

bool TForm2:: CheckIsWinner(){
if(Button1->Text==Button3->Text&&Button1->Text==Button7->Text&&(Button1->Text=='x'||Button1->Text=='o'))
return true;


	for(int i=2,j=0;j<3;j++)
	{

		if(Button1->Text==Button3->Text&&Button1->Text==Button7->Text &&(Button1->Text=='x'||Button1->Text=='o'))
		return true;

		if(Button2->Text==Button3->Text&&Button2->Text==Button4->Text &&(Button2->Text=='x'||Button2->Text=='o'))
		return true;

		if(Button5->Text==Button6->Text&&Button5->Text==Button7->Text &&(Button5->Text=='x'||Button5->Text=='o'))
		return true;

		if(Button6->Text==Button7->Text&&Button6->Text==Button8->Text &&(Button6->Text=='x'||Button6->Text=='o'))
		return true;

		if(Button7->Text==Button8->Text&&Button7->Text==Button9->Text &&(Button7->Text=='x'||Button7->Text=='o'))
		return true;

		if(Button1->Text==Button2->Text&&Button1->Text==Button5->Text &&(Button1->Text=='x'||Button1->Text=='o'))
		return true;

		if(Button1->Text==Button4->Text&&Button1->Text==Button9->Text &&(Button1->Text=='x'||Button1->Text=='o'))
		return true;
	}

	return false;
	}
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
cpsl->Text= cps;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::ButtonClick(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;

			 if(CheckIsWinner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

}
//---------------------------------------------------------------------------


