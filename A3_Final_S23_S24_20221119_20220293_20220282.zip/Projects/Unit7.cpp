//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Unit7.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm7 *Form7;
char cps='x';

bool TForm7:: CheckIsWinner(){
 if(!Button1->Text.IsEmpty() &&Button1->Text==Button2->Text && Button1->Text==Button3->Text)
	return true;

	 if(!Button1->Text.IsEmpty() && Button1->Text==Button4->Text && Button1->Text==Button7->Text)
	return true;

	 if(!Button1->Text.IsEmpty() &&Button1->Text==Button5->Text && Button1->Text==Button9->Text)
	return true;

	 if(!Button2->Text.IsEmpty() &&Button2->Text==Button5->Text && Button2->Text==Button8->Text)
	return true;

	 if(!Button3->Text.IsEmpty() &&Button3->Text==Button6->Text && Button3->Text==Button9->Text)
	return true;

	 if(!Button4->Text.IsEmpty() &&Button4->Text==Button5->Text && Button4->Text==Button6->Text)
	return true;

	 if(!Button7->Text.IsEmpty() &&Button7->Text==Button8->Text && Button7->Text==Button9->Text)
	return true;
	if(!Button3->Text.IsEmpty() &&Button3->Text==Button5->Text && Button3->Text==Button7->Text)
	return true;


	return false;
}
//---------------------------------------------------------------------------
__fastcall TForm7::TForm7(TComponent* Owner)
	: TForm(Owner)
{
			   cpsl->Text=cps;
}
//---------------------------------------------------------------------------
void __fastcall TForm7::ButtonClick(TObject *Sender)
{
 TButton* clickedButton=dynamic_cast<TButton*>(Sender) ;
 clickedButton->Text=cps;

  if(CheckIsWinner()){

		  winningLabel->Text="You WON!!!";
		  return;
		 }
		  else if(!CheckIsWinner()&&!Button1->Text.IsEmpty() && !Button2->Text.IsEmpty() &&!Button3->Text.IsEmpty() &&!Button4->Text.IsEmpty()
	 &&!Button5->Text.IsEmpty() &&!Button6->Text.IsEmpty() &&!Button7->Text.IsEmpty() &&!Button8->Text.IsEmpty() && !Button9->Text.IsEmpty()){

		  winningLabel->Text="draw!!!";
		  return;
		 }

 if(cps=='x')
 cps='o';
 else
	cps='x';
 cpsl->Text=cps;



}
//---------------------------------------------------------------------------
