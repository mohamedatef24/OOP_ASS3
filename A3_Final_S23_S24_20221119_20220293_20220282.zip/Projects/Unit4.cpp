//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm4 *Form4;
char **board;
bool possible[7][7];
int n_rows =  6,n_cols=7;

char cps='x';

bool TForm4::is_winner() {
	for(int i=n_rows-1;i>=0;i--) ///horizontally
	{
		for(int j=0;j<n_cols-3;j++)
		{
			if(board[i][j]==board[i][j+1]&&board[i][j]==board[i][j+2]&&board[i][j]==board[i][j+3]&&(board[i][j]=='x'||board[i][j]=='o')) return true;
		}
	}for(int i=0;i<n_cols;i++) ///vertically
	{
		for(int j=n_rows-1;j>=n_rows-3;j--)
		{
			if(board[j][i]==board[j-1][i]&&board[j][i]==board[j-2][i]&&board[j][i]==board[j-3][i]&&(board[j][i]=='x'||board[j][i]=='o')) return true;
		}
	}
	for(int i=0,y=5;i<3;i++)
	{
		for(int j=0;j<=y-2;j++)
		{
			if(board[i][j]==board[i+1][j+1]&&board[i][j]==board[i+2][j+2]&&board[i][j]==board[i+3][j+3]&&(board[i][j]=='x'||board[i][j]=='o')) return true;
		}
	}
	for(int i=0,y=5;i<3;i++)
	{
		for(int j=6;j>=y-2;j--)
		{
			if(board[i][j]==board[i+1][j-1]&&board[i][j]==board[i+2][j-2]&&board[i][j]==board[i+3][j-3]&&(board[i][j]=='x'||board[i][j]=='o')) return true;
		}
	}
	return false;
}
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
	: TForm(Owner)
{
cpsl->Text= cps;

   board = new char*[n_rows];
   for (int i = 0; i < n_rows; i++) {
	  board [i] = new char[n_cols];
      for (int j = 0; j < n_cols; j++){
         board[i][j] = 0;
         possible[i][j]=0;
   }}
	for(int i=0;i<n_cols;i++) possible[6][i]=1;
}
//---------------------------------------------------------------------------
void __fastcall TForm4::ButtonClick1(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][0]=cps;
			 if(is_winner()){

			 winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------


void __fastcall TForm4::Button2Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button3Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button4Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button5Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button6Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button7Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[0][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button8Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][0]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button9Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button10Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button11Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button12Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button13Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button14Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[1][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button15Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][0]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button16Click(TObject *Sender)
{
        TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button17Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button18Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button19Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button20Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button21Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[2][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button22Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][0]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button23Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button24Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button25Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button26Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button27Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button28Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[3][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button29Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][0]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button30Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button31Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button32Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button33Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button34Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button35Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[4][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button36Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][0]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button37Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][1]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button38Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][2]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button39Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][3]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button40Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][4]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button41Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][5]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button42Click(TObject *Sender)
{
TButton* clickedButton=dynamic_cast<TButton*>(Sender);
		 clickedButton->Text=cps;
			board[5][6]=cps;
			 if(is_winner()){

		  winnerLabel->Text="You WON!!!";
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
}
//---------------------------------------------------------------------------

