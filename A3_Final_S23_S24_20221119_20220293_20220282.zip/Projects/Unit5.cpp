//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include "Unit5.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm5 *Form5;
char **board;

char cps='x';

int n_rows=5;
int n_cols=5;
int X_wins=0;
int O_wins=0;

int n_moves=0;

bool TForm5::is_winner() {
	if(n_moves==24)
	{
        for(int i=0;i<5;i++)// Horizontally
        {
			for(int j=0;j<3;j++)
            {
                if(board[i][j]==board[i][j+1]&&board[i][j]==board[i][j+2])
                {
					if(board[i][j]=='x') ++X_wins;
					else if(board[i][j]=='o') ++O_wins;
                }
            }
        }for(int i=0;i<5;i++)// vertically
        {
            for(int j=0;j<3;j++)
            {
                if(board[j][i]==board[j+1][i]&&board[j][i]==board[j+2][i])
                {
					if(board[j][i]=='x') ++X_wins;
					else if(board[j][i]=='o') ++O_wins;
				}
			}
		}for(int i=0;i<3;i++)// Ldiag
		{
			for(int j=0;j<3;j++)
			{
				if(board[i][j]==board[i+1][j+1]&&board[i][j]==board[i+2][j+2])
				{
					if(board[i][j]=='x') ++X_wins;
					else if(board[i][j]=='o') ++O_wins;
                }
            }
        }for(int i=0;i<3;i++)// Rdiag
        {
            for(int j=4;j>1;j--)
            {
                if(board[i][j]==board[i+1][j-1]&&board[i][j]==board[i+2][j-2])
                {
					if(board[i][j]=='x') ++X_wins;
                    else if(board[i][j]=='o') ++O_wins;
                }
            }
        }
	}
	if(n_moves==24)
	{
		if(X_wins>O_wins){
				  winnerLabel->Text=" X, You WON!!!";
            return true;
        }
		else if(O_wins>X_wins){
				  winnerLabel->Text=" O, You WON!!!";
			return true;
        }
        else {
			winnerLabel->Text="DRAW!!!";
        }
	}
    return false;
}


//---------------------------------------------------------------------------
__fastcall TForm5::TForm5(TComponent* Owner)   //constructor?
	: TForm(Owner)
{
	cpsl->Text= cps;
   board = new char*[n_rows];
   for (int i = 0; i < n_rows; i++) {
	  board [i] = new char[n_cols];
	  for (int j = 0; j < n_cols; j++)
         board[i][j] = 0;
   }

}
//---------------------------------------------------------------------------
void __fastcall TForm5::Button1Click(TObject *Sender)
{
	  TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[0][0]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
 n_moves++;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button2Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[0][1]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button3Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[0][2]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button4Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[0][3]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button5Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[0][4]=cps;
			 if(is_winner()){

			//
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button6Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[1][0]=cps;
			 if(is_winner()){

			//
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button7Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[1][1]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button8Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[1][2]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button9Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[1][3]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button10Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[1][4]=cps;
			 if(is_winner()){

			//
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button11Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[2][0]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button12Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[2][1]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button13Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[2][2]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button14Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[2][3]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button15Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[2][4]=cps;
			 if(is_winner()){

			//
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button16Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[3][0]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button17Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[3][1]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;

n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button18Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[3][2]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button19Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[3][3]=cps;
			 if(is_winner()){

		  //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button20Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[3][4]=cps;
			 if(is_winner()){

		  //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button21Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[4][0]=cps;
			 if(is_winner()){

		  //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button22Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[4][1]=cps;
			 if(is_winner()){

		  //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button23Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[4][2]=cps;
			 if(is_winner()){

		  //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button24Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[4][3]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button25Click(TObject *Sender)
{
TButton* cb=dynamic_cast<TButton*>(Sender);
		 cb->Text=cps;
			board[4][4]=cps;
			 if(is_winner()){

		   //
		  return;
		 }
			 if(cps=='x')
		 cps='o';
		 else
			 cps='x';
		 cpsl->Text=cps;
n_moves++;}
//---------------------------------------------------------------------------

